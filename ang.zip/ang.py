from urllib3.exceptions import InsecureRequestWarning
import urllib3
import requests
import argparse
import json
import sys
import os


class angpocExploit:
    def __init__(self, url, name, method, proxies, path, headers, data, check):
        self.url = url
        self.name = name
        self.method = method
        self.proxies = proxies
        self.path = path
        self.headers = headers
        self.data = data
        self.check = check

    def response_check(self, url, response):
        values = []
        nums = []
        n_p = new_css()
        for i in range(1, int(self.check["value_num"]) + 1):
            nums.append(i)
            values.append(self.check[rf"value{i}"])
        try:
            if int(response.status_code) == int(self.check["code"]):
                if self.check_list_in_text(response.text, values):
                    # print(url + rf" 存在《==={self.name}===》,There are vulnerabilities")
                    n_p.print_green(url + rf" 存在《==={self.name}===》,There are vulnerabilities")
                else:
                    n_p.print_red(url + " ==》There are no vulnerabilities")
        except requests.exceptions.Timeout:
            n_p.print_yellow('连接超时')
        except Exception as e:
            n_p.print_yellow(f"An error occurred: {e}")
            if 'HTTPSConnectionPool' in str(e) or 'Burp Suite Professional' in str(e):
                n_p.print_red('证书错误')
            else:
                print(str(e))

    def check_list_in_text(self, response_text, check_list):
        return all(str(param) in str(response_text) for param in check_list)

    def request_method(self, url):
        # 一定要禁止自动重定向，否则部分poc报错
        if self.method == "GET":
            response = requests.request(method=self.method, url=url, proxies=self.proxies, headers=self.headers,
                                        verify=False, allow_redirects=False)
            return response
        elif self.method == "POST":
            response = requests.request(method=self.method, url=url, proxies=self.proxies, headers=self.headers,
                                        data=self.data, verify=False, allow_redirects=False)
            return response
        elif self.method == "PUT":
            response = requests.request(method=self.method, url=url, proxies=self.proxies, headers=self.headers,
                                        data=self.data, verify=False, allow_redirects=False)
            return response

    def ptv(self):
        try:
            url = self.url + self.path
            urllib3.disable_warnings(InsecureRequestWarning)
            response = self.request_method(url)
            self.response_check(url, response)
        except requests.exceptions.Timeout:
            print('连接超时')
        except Exception as e:
            if 'HTTPSConnectionPool' in str(e) or 'Burp Suite Professional' in str(e):
                print('证书错误')
            else:
                print(str(e))


class poc_dispose:
    def __init__(self):
        pass

    # 查找poc
    # 函数创建时间：2025/3/9
    def find_poc(self):
        poc_dir = rf'poc'
        json_files = []
        for root, dirs, files in os.walk(poc_dir):
            for file in files:
                if file.endswith('.json'):
                    json_files.append(os.path.join(root, file))
        return json_files


#   爬虫模块
class crawlerIng:
    def __init__(self):
        pass

    def download_file(self, url, save_path, proxies, chunk_size=1024 * 1024):
        n_p = new_css()
        try:
            response = requests.get(url, proxies=proxies, stream=True)
            response.raise_for_status()
            total_size = int(response.headers.get('Content-Length', 0))  # 获取文件大小
            downloaded_size = 0

            with open(save_path, 'wb') as file:
                for chunk in response.iter_content(chunk_size=chunk_size):
                    if chunk:
                        file.write(chunk)
                        downloaded_size += len(chunk)
                        n_p.print_green(f"下载进度: {downloaded_size}/{total_size} bytes", end='\r')
            n_p.print_vt("\n下载完成")
        except requests.exceptions.RequestException as e:
            n_p.print_red(f"Request error: {e}")
        except IOError as e:
            n_p.print_red(f"File operation error: {e}")


class pocRun:
    def __init__(self):
        pass

    def poc_running(self, url):
        poc_files = poc_dispose().find_poc()
        for file in poc_files:
            try:
                with open(rf'{file}', 'r', encoding='utf-8') as data:
                    config = json.load(data)
                name = config['name']
                method = config['method']
                proxy = config['proxies']
                path = config['path']
                headers = config['headers']
                data = config['data']
                check = config['check']
                url = url
                a = angpocExploit(url, name, method, proxy, path, headers, data, check)
                a.ptv()
            except:
                print(file + " ==> POC错误")

    def more_poc_running(self, urls):
        with open(rf'{urls}', 'r', encoding='utf-8') as file:
            data = file.read()
        for url in data.split('\n'):
            poc_files = poc_dispose().find_poc()
            for file in poc_files:
                try:
                    with open(rf'{file}', 'r', encoding='utf-8') as data:
                        config = json.load(data)
                    name = config['name']
                    method = config['method']
                    proxy = config['proxies']
                    path = config['path']
                    headers = config['headers']
                    data = config['data']
                    check = config['check']
                    url = url
                    a = angpocExploit(url, name, method, proxy, path, headers, data, check)
                    a.ptv()
                except:
                    print(file + " ==> POC错误")

    # # 以后再写
    def goby_Poc_Run(self, url):
        pass


class run_fast:
    def __init__(self):
        pass


## 外观类
class new_css:
    def __init__(self):
        pass

    def print_green(self, text, end='\n'):
        print(f"\033[32m{text}\033[0m", end=end)

    def print_yellow(self, text, end='\n'):
        print(f"\033[33m{text}\033[0m", end=end)

    def print_red(self, text, end='\n'):
        print(f"\033[31m{text}\033[0m", end=end)

    def print_vt(self, text, end='\n'):
        print(f"\033[35m{text}\033[0m", end=end)

    def ascii_Logo_Ang(self):
        return (r"""                                                                                                      
           ,---,                               
          '  .' \                              
         /  ;    '.          ,---,             
        :  :       \     ,-+-. /  |  ,----._,. 
        :  |   /\   \   ,--.'|'   | /   /  ' / 
        |  :  ' ;.   : |   |  ,"' ||   :     | 
        |  |  ;/  \   \|   | /  | ||   | .\  . 
        '  :  | \  \ ,'|   | |  | |.   ; ';  | 
        |  |  '  '--'  |   | |  |/ '   .   . | 
        |  :  :        |   | |--'   `---`-'| | 
        |  | ,'        |   |/       .'__/\_: | 
        `--''          '---'        |   :    : 
                                     \   \  /  
                                      `--`-'   
                """)

    def ascii_Logo_windows(self):
        return (r"""
                    ....,,:;+ccllll
      ...,,+:;  cllllllllllllllllll
,cclllllllllll  lllllllllllllllllll
llllllllllllll  lllllllllllllllllll
llllllllllllll  lllllllllllllllllll
llllllllllllll  lllllllllllllllllll
llllllllllllll  lllllllllllllllllll
llllllllllllll  lllllllllllllllllll

llllllllllllll  lllllllllllllllllll
llllllllllllll  lllllllllllllllllll
llllllllllllll  lllllllllllllllllll
llllllllllllll  lllllllllllllllllll
llllllllllllll  lllllllllllllllllll
`'ccllllllllll  lllllllllllllllllll
       `' \\*::  :ccllllllllllllllll
                       ````''*::cll
        """)

    def ascii_Logo_mac(self):
        return (r"""
                 ,xNMM.
               .OMMMMo
               OMMM0,
     .;loddo:' loolloddol;.
   cKMMMMMMMMMMNWMMMMMMMMMM0:
${c2} .KMMMMMMMMMMMMMMMMMMMMMMMWd.
 XMMMMMMMMMMMMMMMMMMMMMMMX.
${c3};MMMMMMMMMMMMMMMMMMMMMMMM:
:MMMMMMMMMMMMMMMMMMMMMMMM:
${c4}.MMMMMMMMMMMMMMMMMMMMMMMMX.
 kMMMMMMMMMMMMMMMMMMMMMMMMWd.
 ${c5}.XMMMMMMMMMMMMMMMMMMMMMMMMMMk
  .XMMMMMMMMMMMMMMMMMMMMMMMMK.
    ${c6}kMMMMMMMMMMMMMMMMMMMMMMd
     ;KMMMMMMMWXXWMMMMMMMk.
       .cooc,.    .,coo:.

        """)

    def ascii_Logo_gnu(self):
        return (r"""
                 _-`````-,                 
  .'   .- - |          | - -.  `.
 /.'  /                     `.   \
:/   :      _...   ..._      ``   :
::   :     /._ .`:'_.._\.    ||   :
::    `._ ./  ,`  :    \ . _.''   .
`:.      /   |  -.  \-. \\_      /
  \:._ _/  .'   .@)  \@) ` `\ ,.'
     _/,--'       .- .\,-.`--`.
       ,'/''     (( \ `  )
        /'/'  \    `-'  (
         '/''  `._,-----'
          ''/'    .,---'
           ''/'      ;:
             ''/''  ''/
               ''/''/''
                 '/'/'
                  `;
        """)


def main():
    pocrun = pocRun()
    cra = crawlerIng()
    n_p = new_css()
    n_p.print_vt("测试版本v1.0")
    parser = argparse.ArgumentParser(description="测试版本v1.0")
    subparsers = parser.add_subparsers(dest="command", help="当前可选命令")
    scan_parser = subparsers.add_parser("scan", help="POC主动扫描")
    download_parser = subparsers.add_parser("download", help="下载大型文件")
    os_parser = subparsers.add_parser("os", help="系统相关工具")

    scan_group = scan_parser.add_mutually_exclusive_group(required=True)
    scan_group.add_argument("-u", "--url", type=str, help="单个目标的 URL 或 IP 地址")
    scan_group.add_argument("-U", "--urls", type=str, help="包含多个目标的文件路径")
    # scan_parser.add_argument("-p", "--p", type=int, help="代理")

    download_group = download_parser.add_mutually_exclusive_group(required=True)
    download_group.add_argument("-u", "--url", type=str, help="下载地址")
    download_parser.add_argument("-s", "--savepath", type=str, required=True, help="保存路径")
    download_parser.add_argument("-p", "--proxy", type=str,
                                 help="目前仅支持http/https代理服务器地址和端口，格式为 IP:端口")

    args = parser.parse_args()
    if args.command == "scan":
        if args.url:
            try:
                pocrun.poc_running(args.url)
            except Exception as e:
                n_p.print_red(e)
        if args.urls:
            try:
                pocrun.more_poc_running(args.urls)
            except Exception as e:
                n_p.print_red(e)

        elif args.urls:
            print(f"开始扫描多个目标，文件路径: {args.urls}")
    elif args.command == "download":
        if args.url:
            proxies = None
            if args.proxy:
                proxy = args.proxy
                proxies = {
                    "http": f"http://{proxy}",
                    "https": f"http://{proxy}"
                }
            cra.download_file(args.url, args.savepath, proxies=proxies)

    else:
        parser.print_help()


# http://52.210.133.58

if __name__ == "__main__":
    a = new_css()
    a.print_red(a.ascii_Logo_Ang())
    a.ascii_Logo_gnu()
    a.ascii_Logo_mac()
    a.ascii_Logo_windows()
    main()

#   使用过程：
#    http://pic3.sfacg.com/Pic/OnlineComic4/ZLSZ/ZP/100/004.jpg?p=http://www.baidu.com/img/bdlogo.gif

#   第一种模式，使用poc扫描
#   python .\test.py scan -u http://img.mini.minisns.cn
#   python .\test.py scan -u http://52.210.133.58


#   下载文件
#    python .\test.py download -u "http://pic3.sfacg.com/Pic/OnlineComic4/ZLSZ/ZP/100/004.jpg?p=http://www.baidu.com/img/bdlogo.gif" -s 10.png
